﻿=== BizDir ===

Contributors: handydata
Tags: custom-background, custom-logo, custom-menu, custom-logo, featured-images, flexible-header, footer-widgets, full-width-template, sticky-post, theme-options, threaded-comments, translation-ready, one-column, two-columns, three-columns, left-sidebar, right-sidebar, blog
Requires at least: 4.8.0
Tested up to: 5.2.1
Requires PHP: 5.6
Stable tag: 1.0.2
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

BizDir – WordPress directory listing theme built on top of Customify as parent theme and triListing plugin that provides directory listing features. Create your directory listing website in few clicks by using BizDir theme. Features: custom fields, accounts and profiles, advanced search form with filters, reviews and much more. Learn more by visiting theme home page. Let BizDir be one stop directory listing theme solution.

== Changelog ==

= 1.0.2 =

Edit screenshot

= 1.0.1 =

Add license

= 1.0.0 =

* Initial release