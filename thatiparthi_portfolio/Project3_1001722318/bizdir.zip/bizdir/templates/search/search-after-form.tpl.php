<?php
/**
 * This is the template that displays search after wrapped.
 * 
 * @version 1.0.0
 * @package bizdir
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

	</div> <!-- End .trilisting-search-wrap -->
</div>  <!-- End .trilisting-search-slct-wrap -->
